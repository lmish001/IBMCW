package core;

import java.util.LinkedList;

public class Receta {
	Paso[] pasos;
	String ingredientes[];
	String nombre;
	String clase;
	String tipo_plato;
	
	public Receta(Paso[] pasos, String[] ingredientes, String nombre, String clase,
			String tipo_plato) {
		super();
		this.pasos = pasos;
		this.ingredientes = ingredientes;
		this.nombre = nombre;
		this.clase = clase;
		this.tipo_plato = tipo_plato;
	}
	
}
	
