package core;

public class Ingrediente {
	String nombre,clase;

	public Ingrediente(String nombre, String clase) {
		super();
		this.nombre = nombre;
		this.clase = clase;
	}
}
