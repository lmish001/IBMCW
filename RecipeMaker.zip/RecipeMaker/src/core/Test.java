package core;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;
import java.util.Random;

public class Test {
	static LinkedList<Ingrediente> ingredientes = new LinkedList<Ingrediente>();
	static LinkedList<Receta> recetas = new LinkedList<Receta>();
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		//________________________________________________________singredientes______________________________________
		addingrediente("ternera", "CARNE");
		addingrediente("pollo", "CARNE");
		addingrediente("pavo", "CARNE");
		addingrediente("jamon_york", "CARNE");
		
		
		addingrediente("barbacoa", "SALSA");
		addingrediente("bolognesa", "SALSA");
		addingrediente("chile_picante", "SALSA");
		
		addingrediente("atun", "PESCADO");
		addingrediente("salmon", "PESCADO");
		addingrediente("emperados", "PESCADO");
		
		addingrediente("tomate", "VERDURA");
		addingrediente("lechuga", "VERDURA");
		
		addingrediente("judias_verdes", "LEGUMBRE");
		addingrediente("repollo", "LEGUMBRE");
		addingrediente("lentejas", "LEGUMBRE");
		
		addingrediente("naranja", "FRUTA");
		addingrediente("manzana", "FRUTA");
		addingrediente("platano", "FRUTA");
		
		addingrediente("macarrones", "PASTA");
		addingrediente("ravioli", "PASTA");
		
		addingrediente("parmesano", "QUESO");
		addingrediente("queso_de_cabra", "QUESO");
		addingrediente("mozzarella", "QUESO");
		addingrediente("queso_de_cabra", "QUESO");
		
		addingrediente("cereales_integrales", "CEREALES");
		addingrediente("cereales_choco", "CEREALES");
		
		addingrediente("caldo_de_pollo", "LIQUIDO");
		addingrediente("masa", "ALIMENTO");
		addingrediente("masa_integral", "ALIMENTO");
		
		
		
		//________________________________________________________recetas______________________________________
		Paso[] p;
		String[] ing;
		
		p = new Paso[]{new Paso(1, "Preparar la masa: ", "masa"),
						new Paso(2, "Preparar los toppings: ", "parmesano mozzarella queso_de_cabra roquefort"),
						new Paso(3, "Hornear la pizza", "")
		};
		ing = new String[] {"masa", "parmesano", "mozzarella", "queso_de_cabra", "roquefort"};
		recetas.add(new Receta(p, ing, "Pizza 4 quesos", "ITALIANO", "pizza"));
		//
		p = new Paso[]{new Paso(1, "Preparar la masa: ", "masa"),
				new Paso(2, "Preparar los toppings: ", "ternera barbacoa"),
				new Paso(3, "Hornear la pizza", "")
				};
		ing = new String[] {"masa", "ternera","barbacoa"};
		recetas.add(new Receta(p, ing, "Pizza barbacoa", "ITALIANO", "pizza"));
		//
		p = new Paso[]{new Paso(1, "Preparar la masa: ", "masa_integral"),
				new Paso(2, "Preparar los toppings: ", "pollo parmesano"),
				new Paso(3, "Hornear la pizza", "")
				};
		ing = new String[] {"masa_integral", "pollo", "parmesano"};
		recetas.add(new Receta(p, ing, "Pizza carbonara", "ITALIANO", "pizza"));
		//
		p = new Paso[]{new Paso(1, "Preparar la masa: ", "masa"),
				new Paso(2, "Preparar los toppings: ", "jamon_york mozzarella"),
				new Paso(3, "Hornear la pizza", "")
				};
		ing = new String[] {"masa", "jamon_york", "mozzarella"};
		recetas.add(new Receta(p, ing, "Pizza jamon y queso", "ITALIANO", "pizza"));
				
		//________________________________________________________sinergias______________________________________
		
		
		String sinergia[]= new String[ingredientes.size()];
		for (int i = 0; i < sinergia.length; i++) {
			sinergia[i] = ingredientes.get(i).nombre;
		}
		//______________________________________________________________________________________________
		
		
		PrintWriter writer = new PrintWriter("F:/IBM chaf watson/IBMCW-master/recetas.clp", "UTF-8");
		
		writer.println("(definstances ingredientes");
		for (int i = 0; i < ingredientes.size(); i++) {
			writer.println("([ing"+i+"] of "+ingredientes.get(i).clase  +" (id_ingrediente "+ ingredientes.get(i).nombre+"))");
			
		}
		writer.println(")");
		
		writer.println("");
		
		writer.println("(definstances sinergias");
		for (int i = 0; i < sinergia.length; i++) {
			for (int j = 0; j < sinergia.length; j++) {
				if(i!=j) {
					int grado = (new Random().nextInt(20 + 1 - 1) + 1)*5;
					writer.println("(["+i+"s"+j+"] of SINERGIA (id_ingrediente1 "+sinergia[i]+") (id_ingrediente2 "+sinergia[j]+") (grado "+grado+"))");
					writer.println("(["+j+"s"+i+"] of SINERGIA (id_ingrediente1 "+sinergia[j]+") (id_ingrediente2 "+sinergia[i]+") (grado "+grado+"))");
				}
				}
		}
		for (int i = 0; i < recetas.size(); i++) {
			writer.println("(definstances receta"+i);
			String ings= "";
			for (String s : recetas.get(i).ingredientes) {
				ings = ings + " " + s;
			}	
			writer.println("([r"+i+"] of "+recetas.get(i).clase+" (id_receta \""+recetas.get(i).nombre+"\") (tipo_plato "+recetas.get(i).tipo_plato+") (ingredientes "+ings+") (num_ingredientes "+recetas.get(i).ingredientes.length+" ))");
			
			for (int j = 0; j < recetas.get(i).pasos.length; j++) {
				if(recetas.get(i).pasos[j].ingredientes == "") {
					writer.println("([p"+i+j+"] of PASO (id_receta \""+recetas.get(i).nombre+"\") (orden "+recetas.get(i).pasos[j].orden+") (descripcion \""+recetas.get(i).pasos[j].descripcion+"\"))");
				}
				else{
					writer.println("([p"+i+j+"] of PASO (id_receta \""+recetas.get(i).nombre+"\") (orden "+recetas.get(i).pasos[j].orden+") (descripcion \""+recetas.get(i).pasos[j].descripcion+"\") (ingredientes "+recetas.get(i).pasos[j].ingredientes+"))");
				}
			}
			for (int j = 0; j < recetas.get(i).ingredientes.length; j++) {
				for (int k = 0; k < recetas.get(i).pasos.length; k++) {
					if(recetas.get(i).pasos[k].ingredientes.contains(recetas.get(i).ingredientes[j])) {
						int cantidad = (new Random().nextInt(20 + 1 - 1) + 1)*10;
						writer.println("([i"+j+"r"+i+"] of INGREDIENTE_RECETA (id_ingrediente "+recetas.get(i).ingredientes[j]+") (id_receta \""+recetas.get(i).nombre+"\")(paso "+(k+1)+") (cantidad "+cantidad+"))");
						}
					}
				
			}
			
			
			writer.println(")");
		}
		

		writer.close();
	}
	
	public static void addingrediente(String nombre, String clase) {
		ingredientes.add(new Ingrediente(nombre, clase));
	}
}
