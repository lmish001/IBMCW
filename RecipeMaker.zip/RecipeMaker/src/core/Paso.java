package core;

public class Paso {
	int orden;
	String descripcion;
	String ingredientes;
	public Paso(int orden, String descripcion, String ingredientes) {
		super();
		this.orden = orden;
		this.descripcion = descripcion;
		this.ingredientes = ingredientes;
	}
	


}
